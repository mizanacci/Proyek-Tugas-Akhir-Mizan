export const COMMAND_RESULT_STATUSES = Object.freeze([
  'RECEIVED',
  'EXECUTING',
  'SUCCEEDED',
  'FAILED',
  'REJECTED',
  'EXPIRED',
  'INDETERMINATE',
]);

export function parseJsonObject(payload, label) {
  let value = payload;
  if (Buffer.isBuffer(value)) value = value.toString('utf8');
  if (typeof value === 'string') {
    try {
      value = JSON.parse(value);
    } catch {
      throw new Error(label + ' payload is not valid JSON');
    }
  }
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(label + ' payload must be a JSON object');
  }
  return value;
}

function finiteNonNegativeNumber(value, field) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) {
    throw new Error('Invalid sensor field: ' + field);
  }
  return value;
}

function parseVoltageStatus(data, side) {
  const fields = {
    status: 'status_v_' + side,
    suspect: 'suspect_v_' + side,
    warning: 'warning_v_' + side,
    acOff: 'ac_off_v_' + side,
  };
  const present = Object.values(fields).filter((field) =>
    Object.prototype.hasOwnProperty.call(data, field),
  ).length;

  // Older firmware payloads remain readable, but their voltage state is unknown.
  if (present === 0) return 'UNKNOWN';
  if (present !== 4) {
    throw new Error('Incomplete voltage status fields for ' + side);
  }

  const rawStatus = data[fields.status];
  const suspect = data[fields.suspect];
  const warning = data[fields.warning];
  const acOff = data[fields.acOff];

  if (typeof rawStatus !== 'string' ||
      !['NORMAL', 'SUSPECT', 'WARNING'].includes(rawStatus)) {
    throw new Error('Invalid voltage status field: ' + fields.status);
  }
  for (const [name, value] of Object.entries({ suspect, warning, acOff })) {
    if (typeof value !== 'boolean') {
      throw new Error('Invalid voltage status flag for ' + side + ': ' + name);
    }
  }

  const normalized = warning ? 'WARNING'
    : suspect ? 'SUSPECT'
      : acOff ? 'AC_OFF'
        : 'NORMAL';
  const expectedWireStatus = normalized === 'AC_OFF' ? 'NORMAL' : normalized;

  if (rawStatus !== expectedWireStatus ||
      Number(suspect) + Number(warning) + Number(acOff) > 1) {
    throw new Error('Inconsistent voltage status flags for ' + side);
  }

  return normalized;
}

function parseCurrentStatus(data, side) {
  const statusField = 'status_i_' + side;
  const suspectField = 'suspect_i_' + side;
  const hasStatus = Object.prototype.hasOwnProperty.call(data, statusField);
  const hasSuspect = Object.prototype.hasOwnProperty.call(data, suspectField);

  if (!hasStatus && !hasSuspect) return 'UNKNOWN';
  if (!hasStatus || !hasSuspect) {
    throw new Error('Incomplete current status fields for ' + side);
  }

  const status = data[statusField];
  const suspect = data[suspectField];
  if (typeof status !== 'string' || !['NORMAL', 'SUSPECT'].includes(status) ||
      typeof suspect !== 'boolean' || status !== (suspect ? 'SUSPECT' : 'NORMAL')) {
    throw new Error('Inconsistent current status fields for ' + side);
  }

  return status;
}

export function parseSensorPayload(payload) {
  const data = parseJsonObject(payload, 'Sensor');
  const quality = data.kualitas;
  const deviceTimestampMs = data.ts;
  const operationMode = data.mode_operasi === undefined ? "UNKNOWN" : data.mode_operasi;
  const operationModeValid = data.mode_operasi_valid === undefined ? false : data.mode_operasi_valid;
  const allowedOperationModes = ["UNKNOWN", "STANDBY", "RUN", "INVALID"];

  if (!Number.isSafeInteger(quality) || quality < 0 || quality > 15) {
    throw new Error('Invalid sensor field: kualitas must be an integer from 0 to 15');
  }
  if (!Number.isSafeInteger(deviceTimestampMs) || deviceTimestampMs < 0) {
    throw new Error('Invalid sensor field: ts must be a non-negative integer');
  }
  if (typeof operationMode !== "string" || !allowedOperationModes.includes(operationMode)) {
    throw new Error("Invalid sensor field: mode_operasi is not recognized");
  }
  if (typeof operationModeValid !== "boolean") {
    throw new Error("Invalid sensor field: mode_operasi_valid must be boolean");
  }

  const sourceVoltageStatus = parseVoltageStatus(data, 'sumber');
  const loadVoltageStatus = parseVoltageStatus(data, 'beban');
  const sourceCurrentStatus = parseCurrentStatus(data, 'sumber');
  const loadCurrentStatus = parseCurrentStatus(data, 'beban');

  return Object.freeze({
    sourceVoltage: finiteNonNegativeNumber(data.v_sumber, 'v_sumber'),
    loadVoltage: finiteNonNegativeNumber(data.v_beban, 'v_beban'),
    sourceVoltageStatus,
    loadVoltageStatus,
    sourceCurrent: finiteNonNegativeNumber(data.i_sumber, 'i_sumber'),
    loadCurrent: finiteNonNegativeNumber(data.i_beban, 'i_beban'),
    sourceCurrentStatus,
    loadCurrentStatus,
    quality,
    deviceTimestampMs,
    operationMode,
    operationModeValid,
  });
}

export function parseLinkStatusPayload(payload) {
  const data = parseJsonObject(payload, 'Link status');
  if (data.status !== 'NORMAL' && data.status !== 'FAIL') {
    throw new Error('Link status must be NORMAL or FAIL');
  }
  return Object.freeze({
    status: data.status,
    source: typeof data.source === 'string' ? data.source.slice(0, 80) : 'unknown',
  });
}

export function buildTelemetrySnapshot({
  deviceId,
  sensor,
  lruStatus,
  comStatus,
  lruReceivedAt = 0,
  comReceivedAt = 0,
  now = Date.now(),
}) {
  return {
    device_id: deviceId,
    timestamp: now,
    received_at: now,
    device_ts_ms: sensor.deviceTimestampMs,
    v_sumber: sensor.sourceVoltage,
    v_beban: sensor.loadVoltage,
    status_v_sumber: sensor.sourceVoltageStatus || 'UNKNOWN',
    status_v_beban: sensor.loadVoltageStatus || 'UNKNOWN',
    i_sumber: sensor.sourceCurrent,
    i_beban: sensor.loadCurrent,
    status_i_sumber: sensor.sourceCurrentStatus || 'UNKNOWN',
    status_i_beban: sensor.loadCurrentStatus || 'UNKNOWN',
    kualitas: sensor.quality,
    mode_operasi: sensor.operationMode || "UNKNOWN",
    mode_operasi_valid: sensor.operationModeValid === true,
    status_lru: lruStatus || 'UNKNOWN',
    status_lru_received_at: Number.isSafeInteger(lruReceivedAt) && lruReceivedAt > 0
      ? lruReceivedAt : 0,
    status_com: comStatus || 'UNKNOWN',
    status_com_received_at: Number.isSafeInteger(comReceivedAt) && comReceivedAt > 0
      ? comReceivedAt : 0,
    // Current firmware has no independent LBS auxiliary-contact feedback topic.
    // Never infer the physical position from the last requested command.
    status_lbs: 'UNKNOWN',
  };
}

export function evaluateCommandShape(command, now, maxAgeMs) {
  if (command === null || typeof command !== 'object' || Array.isArray(command)) {
    return { ok: false, status: 'REJECTED', reason: 'Command record is not an object.' };
  }
  const allowedFields = new Set([
    'target',
    'action',
    'created_at',
    'created_by_uid',
    'created_by_name',
    'status',
  ]);
  if (Object.keys(command).some((key) => !allowedFields.has(key))) {
    return { ok: false, status: 'REJECTED', reason: 'Command contains an unexpected field.' };
  }
  if (command.status !== 'PENDING') {
    return { ok: false, status: 'REJECTED', reason: 'Only PENDING requests are eligible.' };
  }
  if (command.target !== 'LBS_01') {
    return { ok: false, status: 'REJECTED', reason: 'Unknown command target.' };
  }
  if (command.action !== 'OPEN' && command.action !== 'CLOSE') {
    return { ok: false, status: 'REJECTED', reason: 'Unsupported command action.' };
  }
  if (typeof command.created_by_uid !== 'string' || !command.created_by_uid.trim()) {
    return { ok: false, status: 'REJECTED', reason: 'Command creator UID is missing.' };
  }
  if (typeof command.created_by_name !== 'string' ||
      !command.created_by_name.trim() ||
      command.created_by_name.length > 120) {
    return { ok: false, status: 'REJECTED', reason: 'Command creator name is invalid.' };
  }
  if (!Number.isSafeInteger(command.created_at) || command.created_at <= 0) {
    return { ok: false, status: 'REJECTED', reason: 'Command timestamp is invalid.' };
  }

  const ageMs = now - command.created_at;
  if (ageMs < -5_000) {
    return { ok: false, status: 'REJECTED', reason: 'Command timestamp is in the future.' };
  }
  if (ageMs > maxAgeMs) {
    return { ok: false, status: 'EXPIRED', reason: 'Command expired before gateway processing.' };
  }
  return { ok: true };
}

export function evaluateCommandProfile(command, profile) {
  if (profile === null || typeof profile !== 'object') {
    return { ok: false, reason: 'Creator profile does not exist.' };
  }
  if (profile.isActive !== true || profile.role !== 'operator') {
    return { ok: false, reason: 'Only an active Operator may request LBS control.' };
  }
  if (typeof profile.displayName !== 'string' ||
      profile.displayName !== command.created_by_name) {
    return { ok: false, reason: 'Command creator name does not match the current profile.' };
  }
  return { ok: true };
}

function isFreshTimestamp(timestamp, now, maxAgeMs) {
  return Number.isSafeInteger(timestamp) &&
    timestamp > 0 &&
    timestamp <= now + 5_000 &&
    now - timestamp <= maxAgeMs;
}

export function evaluateDeviceReadiness(state, now, maxAgeMs) {
  if (!state?.mqttConnected) {
    return { ready: false, reason: 'MQTT broker is disconnected.' };
  }
  if (!isFreshTimestamp(state.sensorReceivedAt, now, maxAgeMs)) {
    return { ready: false, reason: 'Sensor telemetry is missing or stale.' };
  }
  // Every non-zero quality bit marks at least one sensor channel as SUSPECT.
  if (state.sensorQuality !== 0) {
    return { ready: false, reason: 'One or more sensor channels are not GOOD.' };
  }
  if (state.lruStatus !== 'NORMAL') {
    return { ready: false, reason: 'LRU status is not NORMAL.' };
  }
  // Current firmware publishes LRU NORMAL once at MQTT connect and then relies
  // on retained LWT FAIL. The gateway clears this cache on every reconnect, so
  // a non-zero timestamp proves the retained/current-session state was received.
  if (!Number.isSafeInteger(state.lruReceivedAt) || state.lruReceivedAt <= 0) {
    return { ready: false, reason: 'LRU status has not been received in this MQTT session.' };
  }
  if (state.comStatus !== 'NORMAL') {
    return { ready: false, reason: 'COM status is not NORMAL.' };
  }
  if (!isFreshTimestamp(state.comReceivedAt, now, maxAgeMs)) {
    return { ready: false, reason: 'COM status heartbeat is missing or stale.' };
  }
  return { ready: true };
}

export function buildRelayPayload(action, mapping) {
  const command = action === 'OPEN' ? mapping.open : action === 'CLOSE' ? mapping.close : null;
  if (command !== 'NO' && command !== 'NC') {
    throw new Error('No explicit OPEN/CLOSE to NO/NC mapping is configured.');
  }
  return JSON.stringify({ command });
}
