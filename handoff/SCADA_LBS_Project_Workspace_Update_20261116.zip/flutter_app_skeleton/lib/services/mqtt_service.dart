/// mqtt_service.dart — Wrapper koneksi MQTT ke HiveMQ Cloud
/// Tugas Akhir SCADA Distribusi Listrik — Almar'u Zaim Mizan (04231006)
///
/// [DRAF] Nilai host/kredensial di bawah adalah placeholder — pindahkan ke
/// mekanisme konfigurasi yang tidak ter-commit ke Git sebelum implementasi
/// akhir (mis. package flutter_dotenv, atau --dart-define saat build).
/// JANGAN commit kredensial asli ke repository publik/kampus.
library;

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/sensor_data.dart';

// Samakan dengan config.h firmware & dokumen 04_Konfigurasi_HiveMQ.md
const String _mqttHost = '57b78f1434be4eee81c34de53a922e06.s1.eu.hivemq.cloud';
const int _mqttPort = 8883;
const String _topicDataSensor = 'scada/mizan/data/sensor';
const String _topicStatusLruf = 'scada/mizan/status/lrufail';
const String _topicStatusComf = 'scada/mizan/status/comfail';

class MqttService extends ChangeNotifier {
  late MqttServerClient _client;
  StreamSubscription<List<MqttReceivedMessage<MqttMessage>>>?
      _updatesSubscription;
  Future<bool>? _connectOperation;
  bool _clientInitialized = false;
  bool _terhubung = false;
  bool _subscriptionReady = false;
  String? _pesanKoneksi;
  String _statusLbs = 'UNKNOWN';
  String? _errorTerakhir;
  String? _lastParseError;
  int _jumlahPayloadSensorDiterima = 0;
  int _jumlahPayloadSensorDiproses = 0;
  String? _clientId;
  final Set<String> _subscriptionsConfirmed = {};
  final Duration sensorStaleAfter;

  SensorData? dataSensorTerbaru;
  StatusLink? statusLRUFail;
  StatusLink? statusCOMFail;
  DateTime? terakhirDataDiterima;
  DateTime? lastMessageReceivedAt;
  bool _dataBasi = true;
  Timer? _timerBasi;

  MqttService({
    this.sensorStaleAfter = const Duration(seconds: 15),
  }) {
    _timerBasi = Timer.periodic(const Duration(seconds: 1), (_) {
      final dataBasiBaru = terakhirDataDiterima == null ||
          DateTime.now().difference(terakhirDataDiterima!) > sensorStaleAfter;
      if (dataBasiBaru != _dataBasi) {
        _dataBasi = dataBasiBaru;
        notifyListeners();
      }
    });
  }

  bool get terhubung => _terhubung;
  bool get subscriptionReady => _subscriptionReady;
  bool get dataBasi => _dataBasi;
  String? get pesanKoneksi => _pesanKoneksi;
  String get statusLbs => _statusLbs;
  String? get errorTerakhir => _errorTerakhir;
  String? get lastParseError => _lastParseError;
  String? get clientIdForDiagnostics => _clientId;
  int get jumlahPayloadSensorDiterima => _jumlahPayloadSensorDiterima;
  int get jumlahPayloadSensorDiproses => _jumlahPayloadSensorDiproses;
  @Deprecated('Relay requests must use the Firebase command queue.')
  int get publishFailureCount => 0;
  List<String> get topicDilanggani => const [
        _topicDataSensor,
        _topicStatusLruf,
        _topicStatusComf,
      ];
  LinkState get koneksiAplikasiState =>
      _terhubung ? LinkState.normal : LinkState.fail;

  SystemConnectionState get statusKoneksiSistem => resolveSystemConnectionState(
        applicationConnected: _terhubung,
        lruState: lruState,
        comState: comState,
        dataStale: _dataBasi,
      );

  LinkState get statusKoneksiSistemState {
    return switch (statusKoneksiSistem) {
      SystemConnectionState.connected => LinkState.normal,
      SystemConnectionState.waitingDevice => LinkState.unknown,
      SystemConnectionState.disconnected ||
      SystemConnectionState.deviceOffline ||
      SystemConnectionState.degraded =>
        LinkState.fail,
    };
  }

  String get statusKoneksiSistemMessage {
    return switch (statusKoneksiSistem) {
      SystemConnectionState.connected => 'Terhubung.',
      SystemConnectionState.disconnected =>
        'Terputus: aplikasi tidak terhubung ke HiveMQ.',
      SystemConnectionState.deviceOffline =>
        'Terputus: ESP32 offline atau data sensor basi.',
      SystemConnectionState.waitingDevice =>
        'Menunggu status ESP32 dan komunikasi PLC.',
      SystemConnectionState.degraded =>
        'Gangguan: komunikasi ESP32-PLC tidak normal.',
    };
  }

  String get koneksiAplikasiMessage => _terhubung
      ? 'Aplikasi terhubung ke HiveMQ Cloud.'
      : (_pesanKoneksi ?? 'Aplikasi terputus dari HiveMQ Cloud.');

  String get koneksiPerangkatMessage {
    if (!_terhubung) {
      return 'Status ESP32 tidak dapat dipantau karena aplikasi terputus.';
    }
    return lruStatusMessage;
  }

  LinkState get lruState {
    final status = statusLRUFail;
    if (status == null) return LinkState.unknown;
    if (!status.normal || _dataBasi || dataSensorTerbaru == null) {
      return LinkState.fail;
    }
    return LinkState.normal;
  }

  String get lruStatusMessage {
    if (!_terhubung) {
      return 'Aplikasi tidak terhubung ke broker MQTT.';
    }
    if (statusLRUFail == null) {
      return 'Menunggu status LRUFail dari ESP32.';
    }
    if (!statusLRUFail!.normal || _dataBasi) {
      return 'LRUFail: ESP32 tidak terhubung MQTT; periksa hotspot/gateway.';
    }
    return 'ESP32 terhubung ke broker MQTT.';
  }

  String get comStatusMessage {
    if (comState == LinkState.fail) {
      return 'COMFail: ESP32 tidak terhubung atau tidak menerima polling PLC.';
    }
    if (comState == LinkState.unknown) {
      return 'Menunggu status komunikasi ESP32-PLC.';
    }
    return 'Komunikasi ESP32-PLC normal.';
  }

  LinkState get comState => statusCOMFail == null
      ? LinkState.unknown
      : (statusCOMFail!.normal ? LinkState.normal : LinkState.fail);

  String? get alasanTidakBisaKirim {
    if (!terhubung) return 'Belum terhubung ke server MQTT.';
    if (lruState == LinkState.unknown) {
      return 'Menunggu status LRUFail/COMFail dari perangkat…';
    }
    if (lruState == LinkState.fail) {
      return 'LRUFail: ESP32 terputus dari broker.';
    }
    if (comState == LinkState.unknown) {
      return 'Menunggu status COMFail dari perangkat.';
    }
    if (comState == LinkState.fail) {
      return 'COMFail: komunikasi Modbus RTU ESP32–PLC bermasalah.';
    }
    if (dataBasi) {
      return 'Data sensor tidak diperbarui lebih dari 5 detik.';
    }
    return null;
  }

  Future<bool> connectForRole(UserRole role, String uid) async {
    _pesanKoneksi = 'MQTT access is owned by the SCADA gateway.';
    notifyListeners();
    return false;
  }

  Future<String> clientIdUntukInstalasi() async {
    final preferences = await SharedPreferences.getInstance();
    var installationId = preferences.getString('mqtt_installation_id');
    if (installationId == null) {
      final random = Random.secure();
      installationId = List.generate(
        16,
        (_) => random.nextInt(256).toRadixString(16).padLeft(2, '0'),
      ).join();
      await preferences.setString('mqtt_installation_id', installationId);
    }
    return 'flutter-$installationId';
  }

  /// Panggil sekali (mis. dari initState halaman utama setelah login) dengan
  /// kredensial spesifik role/user yang sedang login. clientId HARUS unik
  /// per instalasi aplikasi agar tidak bentrok dengan sesi ESP32/aplikasi
  /// lain yang terhubung ke cluster yang sama.
  Future<bool> connect({
    required String username,
    required String password,
    required String clientId,
  }) {
    _clientId = clientId;
    if (_terhubung) return Future.value(true);
    final activeOperation = _connectOperation;
    if (activeOperation != null) return activeOperation;

    final operation = _connect(
      username: username,
      password: password,
      clientId: clientId,
    );
    _connectOperation = operation;
    return operation.whenComplete(() {
      if (identical(_connectOperation, operation)) _connectOperation = null;
    });
  }

  Future<bool> _connect({
    required String username,
    required String password,
    required String clientId,
  }) async {
    if (username.trim().isEmpty || password.isEmpty) {
      _pesanKoneksi =
          'Kredensial MQTT belum diisi. Buat user Flutter di HiveMQ '
          'Access Management dan jalankan aplikasi dengan --dart-define.';
      notifyListeners();
      return false;
    }

    await _updatesSubscription?.cancel();
    if (_clientInitialized) _client.disconnect();
    _client = MqttServerClient.withPort(_mqttHost, clientId, _mqttPort);
    _clientInitialized = true;
    _client.secure = true;
    _client.securityContext = SecurityContext.defaultContext;
    _client.keepAlivePeriod = 30;
    _client.autoReconnect = true;
    _client.resubscribeOnAutoReconnect = true;
    _client.onConnected = _onConnected;
    _client.onDisconnected = _onDisconnected;
    _client.onAutoReconnect = () {
      _terhubung = false;
      _subscriptionReady = false;
      _subscriptionsConfirmed.clear();
      unawaited(_updatesSubscription?.cancel());
      _updatesSubscription = null;
      debugPrint('[MQTT] Auto-reconnect dimulai...');
      notifyListeners();
    };
    _client.onAutoReconnected = _onAutoReconnected;
    _client.onSubscribed = _onSubscribed;
    _client.onSubscribeFail = _onSubscribeFail;
    _client.logging(on: false); // set true saat debugging

    final connMessage = MqttConnectMessage()
        .withClientIdentifier(clientId)
        .authenticateAs(username, password)
        .startClean();
    _client.connectionMessage = connMessage;

    try {
      await _client.connect();
    } catch (e) {
      _pesanKoneksi = 'Gagal autentikasi/koneksi MQTT: $e';
      _errorTerakhir = _pesanKoneksi;
      debugPrint('[MQTT] Gagal connect: $e');
      _client.disconnect();
      _terhubung = false;
      notifyListeners();
      return false;
    }

    if (_client.connectionStatus?.state != MqttConnectionState.connected) {
      _pesanKoneksi =
          'Broker menolak koneksi MQTT: ${_client.connectionStatus}';
      _errorTerakhir = _pesanKoneksi;
      debugPrint('[MQTT] Status koneksi gagal: ${_client.connectionStatus}');
      notifyListeners();
      return false;
    }

    _listenForUpdates();
    _subscribeSemuaTopic();
    return true;
  }

  void _onConnected() {
    _terhubung = true;
    _subscriptionReady = false;
    _pesanKoneksi = null;
    _errorTerakhir = null;
    notifyListeners();
    debugPrint('[MQTT] Terhubung.');
  }

  void _onDisconnected() {
    _terhubung = false;
    _subscriptionReady = false;
    _pesanKoneksi ??= 'Koneksi MQTT terputus.';
    statusLRUFail = null;
    statusCOMFail = null;
    dataSensorTerbaru = null;
    terakhirDataDiterima = null;
    lastMessageReceivedAt = null;
    _statusLbs = 'UNKNOWN';
    _dataBasi = true;
    notifyListeners();
    debugPrint('[MQTT] Terputus.');
  }

  void _onAutoReconnected() {
    _terhubung = true;
    _pesanKoneksi = null;
    _listenForUpdates();
    notifyListeners();
    debugPrint('[MQTT] Terhubung kembali.');
  }

  void _onSubscribed(String topic) {
    _subscriptionsConfirmed.add(topic);
    _subscriptionReady =
        _subscriptionsConfirmed.length == topicDilanggani.length;
    notifyListeners();
    debugPrint('[MQTT] Subscription aktif: $topic');
  }

  void _onSubscribeFail(String topic) {
    _subscriptionReady = false;
    _errorTerakhir = 'Broker menolak subscription topic $topic.';
    notifyListeners();
    debugPrint('[MQTT] Subscription gagal: $topic');
  }

  void _subscribeSemuaTopic() {
    _subscriptionsConfirmed.clear();
    _subscriptionReady = false;
    _client.subscribe(_topicDataSensor, MqttQos.atMostOnce);
    _client.subscribe(_topicStatusLruf, MqttQos.atLeastOnce);
    _client.subscribe(_topicStatusComf, MqttQos.atLeastOnce);
  }

  void _listenForUpdates() {
    _updatesSubscription?.cancel();
    final updates = _client.updates;
    if (updates == null) return;
    _updatesSubscription = updates.listen((event) {
      if (event.isEmpty) return;
      final MqttPublishMessage recMess = event[0].payload as MqttPublishMessage;
      final String payload =
          MqttPublishPayload.bytesToStringAsString(recMess.payload.message);
      final String topic = event[0].topic;
      lastMessageReceivedAt = DateTime.now();
      if (topic == _topicDataSensor) _jumlahPayloadSensorDiterima++;

      try {
        final Map<String, dynamic> json = jsonDecode(payload);
        if (topic == _topicDataSensor) {
          dataSensorTerbaru = SensorData.fromJson(json);
          terakhirDataDiterima = DateTime.now();
          _jumlahPayloadSensorDiproses++;
          debugPrint(
            '[MQTT] Payload sensor diproses topic=$topic '
            'panjang=${payload.length} '
            'terakhir=${terakhirDataDiterima!.toIso8601String()} '
            'total=$_jumlahPayloadSensorDiproses',
          );
          if (_dataBasi) _dataBasi = false;
          _lastParseError = null;
        } else if (topic == _topicStatusLruf) {
          statusLRUFail = StatusLink.fromJson(json);
        } else if (topic == _topicStatusComf) {
          statusCOMFail = StatusLink.fromJson(json);
        }
        notifyListeners();
      } catch (e) {
        _errorTerakhir = 'Payload MQTT topic $topic tidak valid: $e';
        if (topic == _topicDataSensor) _lastParseError = _errorTerakhir;
        debugPrint('[MQTT] Gagal parse payload topic $topic: $e');
        notifyListeners();
      }
    });
  }

  @Deprecated('Relay requests must use ScadaService and the reviewed gateway.')
  bool kirimPerintahRelay(String perintah) {
    _errorTerakhir = 'Direct MQTT relay publishing is disabled.';
    notifyListeners();
    return false;
  }

  void disconnect() {
    if (_clientInitialized) {
      _client.disconnect();
    }
    _onDisconnected();
  }

  @override
  void dispose() {
    _timerBasi?.cancel();
    unawaited(_updatesSubscription?.cancel());
    if (_clientInitialized) _client.disconnect();
    super.dispose();
  }
}
